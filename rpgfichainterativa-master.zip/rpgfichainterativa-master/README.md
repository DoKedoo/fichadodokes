#rpgfichainterativa
#Ficha interativa RPG
#Programa feito em Python 3x
#Sem a necessidade de importação de outras bibliotecas
